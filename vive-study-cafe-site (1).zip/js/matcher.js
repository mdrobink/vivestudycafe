/* Smart Food Matcher — UI controller.
 * Depends on: js/menu-data.js (window.ViveMenu), js/matcher-logic.js (window.ViveMatcher).
 * Works without a build step; the page remains readable if JS fails
 * (the static "Browse the full menu" link is always present). */
(function () {
  "use strict";

  var M = window.ViveMenu;
  var L = window.ViveMatcher;

  var state = { taste: null, meal: null, query: "", result: null, index: 0 };

  var panels = {
    1: document.getElementById("step-1"),
    2: document.getElementById("step-2"),
    3: document.getElementById("step-3")
  };
  var titles = { 1: "step-1-title", 2: "step-2-title", 3: "step-3-title" };
  var steps = document.querySelectorAll(".steps__item");
  var resultEl = document.getElementById("result");
  var tasteForm = document.getElementById("taste-form");
  var mealForm = document.getElementById("meal-form");
  var queryBox = document.getElementById("query-box");
  var queryInput = document.getElementById("dish-query");
  var tasteError = document.getElementById("taste-error");
  var mealError = document.getElementById("meal-error");

  /* ---------- small helpers ---------- */
  function el(tag, attrs, children) {
    var n = document.createElement(tag);
    if (attrs) Object.keys(attrs).forEach(function (k) {
      if (k === "text") n.textContent = attrs[k];
      else if (k === "class") n.className = attrs[k];
      else n.setAttribute(k, attrs[k]);
    });
    (children || []).forEach(function (c) { if (c) n.appendChild(c); });
    return n;
  }

  // Image with a styled fallback if it fails to load
  function image(src, alt, cls) {
    if (!src) return el("div", { class: "img-fallback " + (cls || ""), role: "img", "aria-label": "Image not available", text: "Image coming soon" });
    return el("img", { src: src, alt: alt || "", class: cls || "", loading: "lazy", decoding: "async", width: "900", height: "491" });
  }
  document.addEventListener("error", function (e) {
    var t = e.target;
    if (!t || t.tagName !== "IMG" || t.getAttribute("data-failed")) return;
    t.setAttribute("data-failed", "1");
    var box = el("div", { class: "img-fallback " + (t.className || ""), role: "img", "aria-label": t.alt || "Image not available", text: "Image coming soon" });
    if (t.parentNode) t.parentNode.replaceChild(box, t);
  }, true);

  function renderOptions(container, name, list, groupKey) {
    list.forEach(function (opt, i) {
      var id = name + "-" + opt.id;
      var input = el("input", { type: "radio", name: name, value: opt.id, id: id });
      var body = el("span", { class: "opt__body" }, [
        el("strong", { class: "opt__label", text: opt.label }),
        el("small", { class: "opt__hint", text: opt.hint || "" })
      ]);
      var label = el("label", { class: "opt", for: id }, [input, body]);
      label.style.setProperty("--d", (i * 45) + "ms");
      container.appendChild(label);
    });
  }

  /* ---------- Steps ---------- */
  function goTo(n, silent) {
    Object.keys(panels).forEach(function (k) { panels[k].hidden = Number(k) !== n; });
    Array.prototype.forEach.call(steps, function (li) {
      var s = Number(li.getAttribute("data-step"));
      li.classList.toggle("is-done", s < n);
      if (s === n) li.setAttribute("aria-current", "step"); else li.removeAttribute("aria-current");
    });
    if (silent) return;
    var heading = document.getElementById(titles[n]);
    if (heading) heading.focus({ preventScroll: false });
    window.scrollTo({ top: 0, behavior: "auto" });
  }

  function checked(form, name) {
    var r = form.querySelector('input[name="' + name + '"]:checked');
    return r ? r.value : null;
  }

  /* ---------- Build option lists ---------- */
  renderOptions(document.getElementById("taste-options"), "taste", L.TASTES);
  renderOptions(document.getElementById("meal-options"), "meal", L.MEALS);

  // Show the dish-name search only for "Other menu item"
  mealForm.addEventListener("change", function () {
    var isOther = checked(mealForm, "meal") === "other";
    queryBox.hidden = !isOther;
    mealError.hidden = true;
  });
  tasteForm.addEventListener("change", function () { tasteError.hidden = true; });

  /* ---------- Step 1 ---------- */
  tasteForm.addEventListener("submit", function (e) {
    e.preventDefault();
    var t = checked(tasteForm, "taste");
    if (!t) { tasteError.hidden = false; tasteForm.querySelector("input").focus(); return; }
    state.taste = t;
    goTo(2);
  });

  /* ---------- Step 2 ---------- */
  document.getElementById("back-to-1").addEventListener("click", function () { goTo(1); });

  mealForm.addEventListener("submit", function (e) {
    e.preventDefault();
    var m = checked(mealForm, "meal");
    if (!m) { mealError.textContent = "Please choose a meal type to continue."; mealError.hidden = false; mealForm.querySelector("input").focus(); return; }
    state.meal = m;
    state.query = queryInput.value;
    if (m === "other" && !state.query.trim()) {
      mealError.textContent = "Please type a dish name to search, or choose a different meal type.";
      mealError.hidden = false;
      queryInput.focus();
      return;
    }
    state.index = 0;
    runMatch();
  });

  /* ---------- Matching ---------- */
  function runMatch() {
    state.result = L.recommend(M.items, { taste: state.taste, meal: state.meal, query: state.query });
    state.index = 0;
    goTo(3);
    renderResult();
  }

  function actionButton(label, cls, onClick) {
    var b = el("button", { type: "button", class: "btn " + cls, text: label });
    b.addEventListener("click", onClick);
    return b;
  }

  function renderResult() {
    var res = state.result;
    resultEl.innerHTML = "";

    if (res.status === "need-query") {
      resultEl.appendChild(el("p", { class: "notice", text: res.note }));
      resultEl.appendChild(el("div", { class: "result-actions" }, [
        actionButton("Back to meal options", "btn--ghost", function () { goTo(2); })
      ]));
      return;
    }

    if (res.status === "no-match") {
      var box = el("div", { class: "nomatch" });
      box.appendChild(el("h3", { text: "No match found" }));
      box.appendChild(el("p", { text: res.note }));
      box.appendChild(el("p", { class: "nomatch__hint", text: "We have not made a recommendation. You can try a different dish name, or change your selections." }));
      box.appendChild(el("div", { class: "result-actions" }, [
        actionButton("Try Again", "btn--primary", function () {
          goTo(2);
          if (state.meal === "other") queryInput.focus();
        }),
        actionButton("Change my selections", "btn--ghost", function () { goTo(1); })
      ]));
      resultEl.appendChild(box);
      return;
    }

    // status: match | conflict
    var pool = res.pool;
    var item = pool[state.index % pool.length];
    var cat = M.categoryById[item.category];

    if (res.status === "conflict") {
      resultEl.appendChild(el("p", { class: "notice notice--warn", role: "note", text: res.note }));
    } else if (res.note) {
      resultEl.appendChild(el("p", { class: "notice", text: res.note }));
    }

    var card = el("article", { class: "result-card", "aria-labelledby": "result-name" });
    // Menu image paths are relative to the site root; this page is one folder down.
    card.appendChild(el("div", { class: "result-card__media" }, [image(cat.image ? "../" + cat.image : null, cat.imageAlt, "")]));

    var body = el("div", { class: "result-card__body" });
    body.appendChild(el("span", { class: "result-card__cat", text: cat.name }));
    body.appendChild(el("h3", { class: "result-card__name", id: "result-name", text: item.name }));
    body.appendChild(el("p", { class: "result-card__price", text: item.priceLabel }));
    if (item.description) {
      body.appendChild(el("p", { class: "result-card__desc", text: item.description }));
    } else {
      body.appendChild(el("p", { class: "result-card__desc result-card__desc--none", text: "No description has been supplied for this item." }));
    }
    body.appendChild(el("p", { class: "result-card__count", text: "Option " + ((state.index % pool.length) + 1) + " of " + pool.length + " in " + (res.mealLabel || "this selection") }));

    var actions = el("div", { class: "result-actions" });
    var menuLink = el("a", {
      class: "btn btn--primary",
      href: "../?category=" + encodeURIComponent(item.category) + "#menu",
      text: "View Full Menu"
    });
    actions.appendChild(menuLink);
    var another = actionButton("Try Another Match", "btn--ghost", function () {
      state.index = (state.index + 1) % pool.length;
      renderResult();
      var h = document.getElementById("result-name");
      if (h) h.focus();
    });
    if (pool.length < 2) { another.disabled = true; another.setAttribute("aria-describedby", "only-one"); }
    actions.appendChild(another);
    body.appendChild(actions);
    if (pool.length < 2) body.appendChild(el("p", { class: "field-hint", id: "only-one", text: "This is the only item that fits these selections." }));

    body.appendChild(el("div", { class: "result-actions result-actions--secondary" }, [
      actionButton("Change my selections", "btn--text", function () { goTo(1); })
    ]));

    card.appendChild(body);
    resultEl.appendChild(card);

    // Keep the result heading focusable for screen readers
    var h3 = document.getElementById("result-name");
    if (h3) h3.setAttribute("tabindex", "-1");
  }

  // Initial state: show step 1 without moving focus on page load
  goTo(1, true);
})();
