/*
 * Vive Study Cafe — cart and checkout rules (pure functions, no DOM).
 * Browser: window.ViveCart. Node tests: require().
 *
 * Demo mode: carts are kept in localStorage on this device only. Nothing is
 * sent to the restaurant and no payment is taken. Replace the submit step in
 * js/order.js when a real backend or payment gateway is connected.
 */
(function (root) {
  "use strict";

  var KEY = "vive-demo-cart-v1";
  var MAX_QTY = 50;

  var PAYMENT_METHODS = [
    { id: "bkash", name: "bKash", kind: "Mobile wallet", mono: "bK",
      note: "bKash is a mobile wallet option. This demo does not take payment. Live bKash payment is not connected yet." },
    { id: "nagad", name: "Nagad", kind: "Mobile wallet", mono: "Ng",
      note: "Nagad is a mobile wallet option. This demo does not take payment. Live Nagad payment is not connected yet." },
    { id: "upay", name: "Upay", kind: "Mobile wallet", mono: "Up",
      note: "Upay is a mobile wallet option. This demo does not take payment. Live Upay payment is not connected yet." },
    { id: "card", name: "Debit / Credit Card", kind: "Card", mono: "\u25AD",
      note: "Card payment is shown for preview only. Card details are never entered on this website." },
    { id: "cod", name: "Cash on Delivery", kind: "Pay when it arrives", mono: "\u09F3",
      note: "Cash on delivery needs a confirmed delivery service. Availability and any delivery fee are to be confirmed." }
  ];

  var ORDER_TYPES = [
    { id: "in-house", name: "In-house", hint: "Enjoy your order at the cafe" },
    { id: "delivery", name: "Delivery", hint: "Availability and fee to be confirmed" }
  ];

  function sanitize(obj) {
    var out = {};
    if (!obj || typeof obj !== "object") return out;
    Object.keys(obj).forEach(function (id) {
      var q = parseInt(obj[id], 10);
      if (q > 0) out[id] = Math.min(MAX_QTY, q);
    });
    return out;
  }

  function load(storage) {
    try { return sanitize(JSON.parse(storage.getItem(KEY) || "{}")); } catch (e) { return {}; }
  }

  function save(storage, cart) {
    try { storage.setItem(KEY, JSON.stringify(sanitize(cart))); } catch (e) { /* storage may be blocked; cart still works for this page */ }
  }

  function clone(cart) { var c = {}; Object.keys(cart).forEach(function (k) { c[k] = cart[k]; }); return c; }

  function add(cart, id, n) {
    var c = clone(cart);
    c[id] = Math.min(MAX_QTY, (c[id] || 0) + (n || 1));
    return c;
  }

  function setQty(cart, id, qty) {
    var c = clone(cart);
    if (qty <= 0 || isNaN(qty)) delete c[id];
    else c[id] = Math.min(MAX_QTY, qty);
    return c;
  }

  function remove(cart, id) { return setQty(cart, id, 0); }

  function isFromPrice(item) { return item.priceLabel.indexOf("From ") === 0; }

  // Lines for items that are in the cart, in menu order
  function lines(cart, items) {
    return items.filter(function (it) { return cart[it.id] > 0; }).map(function (it) {
      return { item: it, qty: cart[it.id], lineTotal: it.price * cart[it.id], isFrom: isFromPrice(it) };
    });
  }

  function totals(lineList) {
    return lineList.reduce(function (t, l) {
      t.subtotal += l.lineTotal;
      t.count += l.qty;
      if (l.isFrom) t.hasFromPrice = true;
      return t;
    }, { subtotal: 0, count: 0, hasFromPrice: false });
  }

  function formatTk(n) { return "Tk " + Number(n).toLocaleString("en-US"); }

  function validate(form) {
    var errors = {};
    var name = String(form.name || "").trim();
    var phone = String(form.phone || "").replace(/[\s-]/g, "");
    if (name.length < 2) errors.name = "Please enter your name (at least 2 characters).";
    if (!/^01[3-9]\d{8}$/.test(phone)) errors.phone = "Enter a valid Bangladeshi mobile number, for example 01XXXXXXXXX.";
    var type = form.orderType;
    if (!ORDER_TYPES.some(function (o) { return o.id === type; })) errors.orderType = "Choose how you want your order.";
    if (type === "delivery" && String(form.address || "").trim().length < 10) errors.address = "Enter a delivery address (at least 10 characters).";
    if (!PAYMENT_METHODS.some(function (p) { return p.id === form.payment; })) errors.payment = "Choose a payment method.";
    return { ok: Object.keys(errors).length === 0, errors: errors };
  }

  // Demo reference: readable, unique enough for a demo, not a real order number
  function demoRef(now) {
    var t = (now || Date.now()).toString(36).toUpperCase();
    return "VIVE-DEMO-" + t.slice(-6);
  }

  var api = {
    KEY: KEY, MAX_QTY: MAX_QTY,
    PAYMENT_METHODS: PAYMENT_METHODS, ORDER_TYPES: ORDER_TYPES,
    load: load, save: save, add: add, setQty: setQty, remove: remove,
    lines: lines, totals: totals, formatTk: formatTk,
    isFromPrice: isFromPrice, validate: validate, demoRef: demoRef
  };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.ViveCart = api;
})(typeof window !== "undefined" ? window : globalThis);
