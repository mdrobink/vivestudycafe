/* Vive Study Cafe — main site behaviour.
 * Requires js/menu-data.js (window.ViveMenu) to be loaded first.
 * Everything here is progressive: without JS, the page is still readable and
 * the links still work. Pointer effects are desktop-only and disabled for
 * prefers-reduced-motion. */
(function () {
  "use strict";

  var M = window.ViveMenu;
  var root = document.documentElement;
  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
  var finePointer = window.matchMedia("(hover: hover) and (pointer: fine)");
  var wideEnough = window.matchMedia("(min-width: 961px)");
  var ORDER_URL = "https://vivestudycafe.engaze.ai/64ff012af4eb0cdeddccd44d/64ff02e1f4eb0cdeddccd838/inHouse?productId=&tableId=";

  /* ---------- Helpers ---------- */
  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        if (k === "text") node.textContent = attrs[k];
        else if (k === "class") node.className = attrs[k];
        else node.setAttribute(k, attrs[k]);
      });
    }
    (children || []).forEach(function (c) { if (c) node.appendChild(c); });
    return node;
  }
  function normalise(s) { return String(s || "").toLowerCase().replace(/\s+/g, " ").trim(); }

  /* Image with graceful fallback. The capture-phase error listener below swaps
   * a failed <img> for a styled placeholder. */
  function image(src, alt, cls, extra) {
    if (!src) return placeholder(alt || "", cls);
    var img = el("img", Object.assign({ src: src, alt: alt || "", loading: "lazy", decoding: "async", class: cls || "" }, extra || {}));
    return img;
  }
  function placeholder(label, cls) {
    return el("div", { class: "img-fallback " + (cls || ""), role: "img", "aria-label": label || "Image not available", text: "" });
  }
  /* Per-item photo: images/items/<id>.jpg. If it is missing, fall back to the
   * category image (data-fallback), then to the "coming soon" placeholder. */
  function itemImage(it, cat, cls) {
    var img = image("images/items/" + it.id + ".jpg", it.name, cls, { width: "600", height: "450" });
    if (img.tagName === "IMG" && cat && cat.image) img.setAttribute("data-fallback", cat.image);
    return img;
  }
  document.addEventListener("error", function (e) {
    var t = e.target;
    if (t && t.tagName === "IMG" && t.getAttribute("data-fallback") && !t.getAttribute("data-fellback")) {
      t.setAttribute("data-fellback", "1");
      t.src = t.getAttribute("data-fallback");
      return;
    }
    if (!t || t.tagName !== "IMG" || t.getAttribute("data-failed")) return;
    t.setAttribute("data-failed", "1");
    var box = el("div", { class: "img-fallback " + (t.className || ""), role: "img", "aria-label": t.alt || "Image not available" });
    box.appendChild(el("span", { text: "Image coming soon" }));
    if (t.parentNode) t.parentNode.replaceChild(box, t);
  }, true);

  /* ---------- External contact links (Facebook, Instagram, Google Maps) ----------
   * Opens a new tab. If the browser or the preview blocks new tabs (for example a
   * sandboxed iframe without allow-popups), show the link with a copy button instead
   * of doing nothing. The anchor keeps target="_blank" rel="noopener noreferrer". */
  function showLinkFallback(a) {
    var holder = a.closest(".social-grid, .footer-social, .footer-list li, .info-card") || a.parentElement;
    var old = holder.querySelector(".link-fallback");
    if (old) old.remove();
    var url = a.href;
    var code = el("code", { class: "link-fallback__url", text: url });
    var copy = el("button", { class: "btn btn--ghost btn--small", type: "button", text: "Copy link" });
    var box = el("div", { class: "link-fallback", role: "status" }, [
      el("p", { text: "This preview cannot open new tabs. Copy this link and open it in your browser:" }),
      code, copy
    ]);
    copy.addEventListener("click", function () {
      function fallbackSelect() {
        var r = document.createRange(); r.selectNodeContents(code);
        var sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(r);
        copy.textContent = "Selected: press Ctrl/Cmd+C";
      }
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(url).then(function () { copy.textContent = "Copied"; }, fallbackSelect);
      } else { fallbackSelect(); }
    });
    holder.appendChild(box);
  }
  document.addEventListener("click", function (e) {
    var a = e.target.closest ? e.target.closest("a[data-ext]") : null;
    if (!a || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button === 1) return;
    e.preventDefault();
    var w = null;
    try { w = window.open(a.href, "_blank"); } catch (err) { w = null; }
    if (w) { try { w.opener = null; } catch (err) { /* cross-origin: ignore */ } return; }
    showLinkFallback(a);
  });

  /* ---------- Order links ----------
   * Opens the existing ordering page in a new tab. If the browser or the
   * preview sandbox blocks pop-ups, it falls back to opening the page in the
   * same frame, so the button always does something. */
  document.addEventListener("click", function (e) {
    var a = e.target.closest ? e.target.closest("a[data-order]") : null;
    if (!a) return;
    if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button === 1) return;
    e.preventDefault();
    var url = a.href;
    var win = null;
    try { win = window.open(url, "_blank"); } catch (err) { win = null; }
    if (win) { try { win.opener = null; } catch (err) { /* ignore */ } }
    else { window.location.href = url; }
  });

  /* ---------- Header scroll state & mobile nav ---------- */
  var header = document.getElementById("top-header");
  function onScrollHeader() { header.classList.toggle("is-scrolled", window.scrollY > 8); }
  window.addEventListener("scroll", onScrollHeader, { passive: true });
  onScrollHeader();

  var toggle = document.querySelector(".menu-toggle");
  var mobileNav = document.getElementById("mobile-nav");

  function setNav(open) {
    toggle.setAttribute("aria-expanded", String(open));
    toggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
    mobileNav.classList.toggle("is-open", open);
    mobileNav.setAttribute("aria-hidden", String(!open));
    document.body.style.overflow = open ? "hidden" : "";
    if (open) {
      var first = mobileNav.querySelector("a");
      if (first) first.focus();
    }
  }
  toggle.addEventListener("click", function () {
    setNav(toggle.getAttribute("aria-expanded") !== "true");
  });
  mobileNav.addEventListener("click", function (e) {
    if (e.target.closest("a")) setNav(false);
  });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && toggle.getAttribute("aria-expanded") === "true") {
      setNav(false);
      toggle.focus();
    }
  });
  wideEnough.addEventListener && wideEnough.addEventListener("change", function (e) {
    if (e.matches) setNav(false);
  });

  /* Smooth scroll is set up only when motion is allowed */
  if (!reduceMotion.matches) root.classList.add("has-smooth-scroll");

  /* Add-to-order button (handled by js/order.js via [data-add]) */
  function addButton(it) {
    return el("button", { class: "add-btn", type: "button", "data-add": it.id, "aria-label": "Add " + it.name + " to your order", text: "Add" });
  }

  /* ---------- Featured picks ---------- */
  var PICK_IDS = ["cappuccino", "mocha-madness", "blue-ocean-lime", "three-layered-club-sandwich", "complete-english-breakfast", "vives-spanish-latte"];
  var picksGrid = document.getElementById("picks-grid");

  PICK_IDS.forEach(function (id, idx) {
    var it = M.itemById[id];
    if (!it) return;
    var cat = M.categoryById[it.category];
    var card = el("article", { class: "pick-card reveal", style: "--d:" + (idx * 90) + "ms", "data-id": it.id });
    var inner = el("div", { class: "tilt-inner" });
    var media = el("div", { class: "pick-card__media" }, [
      itemImage(it, cat, "")
    ]);
    var body = el("div", { class: "pick-card__body" });
    body.appendChild(el("span", { class: "pick-card__cat", text: cat.name }));
    body.appendChild(el("h3", { class: "pick-card__name", text: it.name }));
    if (it.description) body.appendChild(el("p", { class: "pick-card__desc", text: it.description }));
    var foot = el("div", { class: "pick-card__foot" });
    foot.appendChild(el("span", { class: "price", text: it.priceLabel }));
    foot.appendChild(addButton(it));
    var link = el("a", { class: "link-arrow", href: "#menu", "data-category": it.category, text: "See in full menu" });
    link.setAttribute("aria-label", "See " + it.name + " in the full menu");
    foot.appendChild(link);
    body.appendChild(foot);
    inner.appendChild(media);
    inner.appendChild(body);
    card.appendChild(inner);
    picksGrid.appendChild(card);
  });

  /* ---------- Full menu ---------- */
  var sectionsWrap = document.getElementById("menu-sections");
  var chipsWrap = document.getElementById("menu-chips");
  var searchInput = document.getElementById("menu-search");
  var statusEl = document.getElementById("menu-status");
  var emptyEl = document.getElementById("menu-empty");
  var clearBtn = document.getElementById("menu-clear");
  var activeCategory = "all";
  var sectionRefs = [];

  // Chips: "All" + each category (using exact category names)
  function makeChip(id, label) {
    var b = el("button", { class: "chip", type: "button", "data-cat": id, "aria-pressed": "false", text: label });
    b.addEventListener("click", function () { setCategory(id); });
    return b;
  }
  chipsWrap.appendChild(makeChip("all", "All"));
  M.categories.forEach(function (c) { chipsWrap.appendChild(makeChip(c.id, c.name)); });

  // Sections and cards
  M.categories.forEach(function (c) {
    var section = el("section", { class: "menu-section", "data-cat": c.id, "aria-labelledby": "h-" + c.id });
    var head = el("div", { class: "menu-section__head" });
    var thumb = el("div", { class: "menu-section__thumb" }, [image(c.image, c.imageAlt, "", { width: "400", height: "300" })]);
    var titles = el("div");
    var h = el("h3", { class: "menu-section__title", id: "h-" + c.id, text: c.name });
    var count = el("p", { class: "menu-section__count" });
    titles.appendChild(h);
    titles.appendChild(count);
    head.appendChild(thumb);
    head.appendChild(titles);
    section.appendChild(head);

    var list = el("ul", { class: "menu-grid" });
    var cards = [];
    M.itemsIn(c.id).forEach(function (it) {
      var li = el("li", { class: "menu-card-wrap", "data-name": normalise(it.name) });
      var card = el("div", { class: "menu-card" + (it.description ? "" : " menu-card--empty-desc"), "data-id": it.id });
      var inner = el("div", { class: "tilt-inner" });
      var thumb = el("div", { class: "menu-card__thumb" }, [itemImage(it, c, "")]);
      inner.appendChild(thumb);
      var top = el("div", { class: "menu-card__top" });
      top.appendChild(el("h4", { class: "menu-card__name", text: it.name }));
      top.appendChild(el("span", { class: "menu-card__price", text: it.priceLabel }));
      inner.appendChild(top);
      if (it.description) inner.appendChild(el("p", { class: "menu-card__desc", text: it.description }));
      inner.appendChild(el("span", { class: "menu-card__cat", text: c.name }));
      inner.appendChild(addButton(it));
      card.appendChild(inner);
      li.appendChild(card);
      list.appendChild(li);
      cards.push({ li: li, name: normalise(it.name) });
    });
    section.appendChild(list);
    sectionsWrap.appendChild(section);
    sectionRefs.push({ id: c.id, section: section, count: count, cards: cards });
  });

  function applyFilters() {
    var q = normalise(searchInput.value);
    var totalVisible = 0;
    var totalItems = 0;
    sectionRefs.forEach(function (ref) {
      var visibleInSection = 0;
      var inCategory = activeCategory === "all" || activeCategory === ref.id;
      ref.cards.forEach(function (card) {
        var match = !q || card.name.indexOf(q) !== -1;
        card.li.hidden = !match;
        if (match) visibleInSection++;
      });
      if (inCategory) totalItems += ref.cards.length;
      ref.section.hidden = !inCategory || visibleInSection === 0;
      ref.count.textContent = visibleInSection + (visibleInSection === 1 ? " item" : " items");
      if (inCategory) totalVisible += visibleInSection;
    });
    emptyEl.hidden = totalVisible !== 0;
    var catLabel = activeCategory === "all" ? "all categories" : (M.categoryById[activeCategory] || {}).name;
    statusEl.textContent = "Showing " + totalVisible + " of " + totalItems + " items" + (catLabel ? " in " + catLabel : "") + (q ? " matching \u201C" + searchInput.value.trim() + "\u201D" : "") + ".";
  }

  function setCategory(id) {
    activeCategory = id;
    Array.prototype.forEach.call(chipsWrap.querySelectorAll(".chip"), function (chip) {
      chip.setAttribute("aria-pressed", String(chip.getAttribute("data-cat") === id));
    });
    applyFilters();
  }

  searchInput.addEventListener("input", applyFilters);
  clearBtn.addEventListener("click", function () {
    searchInput.value = "";
    setCategory("all");
    searchInput.focus();
  });

  // Links from picks / Matcher can open a specific category: ?category=espresso
  document.addEventListener("click", function (e) {
    var a = e.target.closest("a[data-category]");
    if (a) setCategory(a.getAttribute("data-category"));
  });
  var params = new URLSearchParams(window.location.search);
  var startCat = params.get("category");
  if (startCat && M.categoryById[startCat]) setCategory(startCat);
  else setCategory("all");


  /* ---------- Reveal on scroll ---------- */
  var reveals = Array.prototype.slice.call(document.querySelectorAll(".reveal"));
  if ("IntersectionObserver" in window && !reduceMotion.matches) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -6% 0px" });
    reveals.forEach(function (node) { io.observe(node); });
  } else {
    reveals.forEach(function (node) { node.classList.add("is-visible"); });
  }

  /* ---------- Desktop-only pointer effects ---------- */
  function pointerEffectsOn() { return finePointer.matches && wideEnough.matches && !reduceMotion.matches; }

  // Tilt for product and menu cards (small angles, desktop only)
  function attachTilt(cardEl) {
    var inner = cardEl.querySelector(".tilt-inner");
    if (!inner) return;
    cardEl.addEventListener("pointermove", function (e) {
      if (!pointerEffectsOn()) return;
      var r = cardEl.getBoundingClientRect();
      var px = (e.clientX - r.left) / r.width - 0.5;
      var py = (e.clientY - r.top) / r.height - 0.5;
      var max = cardEl.classList.contains("pick-card") ? 4 : 2.5;
      cardEl.style.setProperty("--rx", (-py * max).toFixed(2) + "deg");
      cardEl.style.setProperty("--ry", (px * max).toFixed(2) + "deg");
    });
    cardEl.addEventListener("pointerleave", function () {
      cardEl.style.setProperty("--rx", "0deg");
      cardEl.style.setProperty("--ry", "0deg");
    });
  }
  document.querySelectorAll(".pick-card").forEach(attachTilt);
  document.querySelectorAll(".menu-card").forEach(attachTilt);

  // Hero: layered parallax (pointer + scroll), desktop only
  var hero = document.getElementById("hero");
  var heroBg = hero.querySelector(".hero__bg");
  var heroCard = document.getElementById("hero-card");
  var heroFloat = document.getElementById("hero-float");
  var ticking = false;
  var pointer = { x: 0.5, y: 0.5 };

  function updateHero() {
    ticking = false;
    if (!pointerEffectsOn()) {
      heroBg.style.transform = "";
      hero.style.setProperty("--card-rx", "4deg");
      hero.style.setProperty("--card-ry", "-10deg");
      hero.style.setProperty("--card-x", "0px");
      hero.style.setProperty("--card-y", "0px");
      hero.style.setProperty("--float-x", "0px");
      hero.style.setProperty("--float-y", "0px");
      return;
    }
    var rect = hero.getBoundingClientRect();
    var inView = rect.bottom > 0 && rect.top < window.innerHeight;
    if (inView) {
      var offset = -rect.top * 0.18;
      heroBg.style.transform = "translate3d(0," + offset.toFixed(1) + "px,0) scale(1.04)";
    }
    var px = pointer.x - 0.5;
    var py = pointer.y - 0.5;
    hero.style.setProperty("--card-rx", (4 + -py * 6).toFixed(2) + "deg");
    hero.style.setProperty("--card-ry", (-10 + px * 8).toFixed(2) + "deg");
    hero.style.setProperty("--card-x", (px * 14).toFixed(1) + "px");
    hero.style.setProperty("--card-y", (py * 10).toFixed(1) + "px");
    hero.style.setProperty("--float-x", (px * -22).toFixed(1) + "px");
    hero.style.setProperty("--float-y", (py * -14).toFixed(1) + "px");
  }
  function requestHero() { if (!ticking) { ticking = true; requestAnimationFrame(updateHero); } }

  hero.addEventListener("pointermove", function (e) {
    if (!pointerEffectsOn()) return;
    var r = hero.getBoundingClientRect();
    pointer.x = (e.clientX - r.left) / r.width;
    pointer.y = (e.clientY - r.top) / r.height;
    requestHero();
  });
  window.addEventListener("scroll", function () { if (pointerEffectsOn()) requestHero(); }, { passive: true });
  window.addEventListener("resize", requestHero);
  [reduceMotion, finePointer, wideEnough].forEach(function (mq) {
    if (mq.addEventListener) mq.addEventListener("change", requestHero);
  });
  requestHero();
})();
