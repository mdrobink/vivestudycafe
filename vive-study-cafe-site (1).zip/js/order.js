/* Vive Study Cafe — in-site order (demo). Requires menu-data.js, cart-logic.js.
 * Demo mode: nothing is sent and no payment is taken. To go live, replace the
 * body of submitDemoOrder() with a call to your backend/payment gateway. */
(function () {
  "use strict";

  var M = window.ViveMenu;
  var C = window.ViveCart;
  var DEMO_MODE = true;

  // Sandboxed or privacy-restricted contexts can throw on localStorage access.
  // Read it defensively; the cart still works in memory when storage is unavailable.
  function getStorage() { try { return window.localStorage; } catch (e) { return null; } }
  var store = getStorage();
  var cart = C.load(store);
  var lastFocus = null;
  var activeModal = null;

  var $ = function (id) { return document.getElementById(id); };
  var drawer = $("cart-drawer"), checkout = $("checkout"), scrim = $("scrim");
  var toastEl = $("toast");

  function el(tag, attrs, children) {
    var n = document.createElement(tag);
    if (attrs) Object.keys(attrs).forEach(function (k) {
      if (k === "text") n.textContent = attrs[k]; else if (k === "class") n.className = attrs[k]; else n.setAttribute(k, attrs[k]);
    });
    (children || []).forEach(function (c) { if (c) n.appendChild(c); });
    return n;
  }

  /* ---------- Cart rendering ---------- */
  function persist() { C.save(store, cart); }

  function render() {
    var ls = C.lines(cart, M.items);
    var t = C.totals(ls);

    var list = $("cart-list");
    list.innerHTML = "";
    ls.forEach(function (l) {
      var row = el("li", { class: "cart-row" });
      var info = el("div", { class: "cart-row__info" }, [
        el("strong", { text: l.item.name }),
        el("small", { text: l.item.priceLabel + (l.isFrom ? " (starting price)" : "") })
      ]);
      var stepper = el("div", { class: "stepper", role: "group", "aria-label": "Quantity for " + l.item.name }, [
        el("button", { type: "button", "data-act": "dec", "data-id": l.item.id, "aria-label": "Decrease quantity", text: "\u2212" }),
        el("span", { class: "stepper__qty", "aria-live": "polite", text: String(l.qty) }),
        el("button", { type: "button", "data-act": "inc", "data-id": l.item.id, "aria-label": "Increase quantity", text: "+" })
      ]);
      var line = el("div", { class: "cart-row__end" }, [
        el("span", { class: "cart-row__total", text: C.formatTk(l.lineTotal) + (l.isFrom ? "+" : "") }),
        el("button", { class: "link-btn", type: "button", "data-act": "remove", "data-id": l.item.id, text: "Remove" })
      ]);
      row.appendChild(info); row.appendChild(stepper); row.appendChild(line);
      list.appendChild(row);
    });

    $("cart-empty").hidden = ls.length > 0;
    $("cart-subtotal").textContent = C.formatTk(t.subtotal) + (t.hasFromPrice ? "+" : "");
    $("cart-note").hidden = !t.hasFromPrice;
    $("cart-note").textContent = "Includes an item with a starting price. The final total is to be confirmed.";
    $("cart-checkout").disabled = t.count === 0;

    var label = t.count === 1 ? "1 item" : t.count + " items";
    $("cart-count").textContent = String(t.count);
    $("cart-count").parentElement.setAttribute("aria-label", "Open your order, " + label);
    $("cart-count").classList.toggle("is-visible", t.count > 0);
  }

  function bumpCount() {
    var c = $("cart-count");
    c.classList.remove("bump"); void c.offsetWidth; c.classList.add("bump");
  }

  function toast(msg) {
    toastEl.textContent = msg;
    toastEl.classList.add("is-shown");
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { toastEl.classList.remove("is-shown"); }, 1800);
  }

  function setCart(next) { cart = next; persist(); render(); }

  /* ---------- Modals: drawer and checkout ---------- */
  function trapFocus(e, root) {
    if (e.key !== "Tab") return;
    var nodes = Array.prototype.filter.call(root.querySelectorAll("button, a[href], input, select, textarea"), function (n) { return !n.disabled && n.offsetParent !== null; });
    if (!nodes.length) return;
    var first = nodes[0], last = nodes[nodes.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  }

  function openModal(modal, focusEl) {
    if (activeModal && activeModal !== modal) closeModal(activeModal, true);
    if (!activeModal) lastFocus = document.activeElement;
    activeModal = modal;
    modal.classList.add("is-open");
    modal.setAttribute("aria-hidden", "false");
    scrim.hidden = false;
    requestAnimationFrame(function () { scrim.classList.add("is-open"); });
    document.body.style.overflow = "hidden";
    if (focusEl) setTimeout(function () { focusEl.focus(); }, 60);
  }

  function closeModal(modal, keepScrim) {
    modal.classList.remove("is-open");
    modal.setAttribute("aria-hidden", "true");
    if (activeModal === modal) activeModal = null;
    if (!keepScrim && !activeModal) {
      scrim.classList.remove("is-open");
      setTimeout(function () { if (!activeModal) scrim.hidden = true; }, 350);
      document.body.style.overflow = "";
      if (lastFocus && lastFocus.focus) lastFocus.focus();
    }
  }

  function openCart() { render(); openModal(drawer, drawer.querySelector(".drawer__head .icon-btn")); }
  function closeCart() { closeModal(drawer); }
  function openCheckout() {
    if (!Object.keys(cart).length) return;
    closeModal(drawer, true);
    prepareCheckout();
    openModal(checkout, $("co-name"));
  }
  function closeCheckout() { closeModal(checkout); }

  document.querySelectorAll("[data-open-order]").forEach(function (b) {
    b.addEventListener("click", function (e) { e.preventDefault(); openCart(); });
  });
  $("cart-open").addEventListener("click", openCart);
  document.querySelectorAll("[data-close-drawer]").forEach(function (b) { b.addEventListener("click", closeCart); });
  document.querySelectorAll("[data-close-checkout]").forEach(function (b) {
    b.addEventListener("click", function () {
      closeCheckout();
      if (b.closest(".co-done")) { document.getElementById("menu").scrollIntoView({ behavior: "smooth", block: "start" }); }
    });
  });
  document.querySelectorAll("[data-back-to-order]").forEach(function (b) {
    b.addEventListener("click", function () { closeModal(checkout, true); openCart(); });
  });
  scrim.addEventListener("click", function () { if (activeModal) closeModal(activeModal); });
  document.querySelectorAll("[data-goto-menu]").forEach(function (b) {
    b.addEventListener("click", function () { closeCart(); document.getElementById("menu").scrollIntoView({ behavior: "smooth", block: "start" }); });
  });
  document.addEventListener("keydown", function (e) {
    if (!activeModal) return;
    if (e.key === "Escape") { closeModal(activeModal); return; }
    trapFocus(e, activeModal);
  });

  /* ---------- Cart actions ---------- */
  document.addEventListener("click", function (e) {
    var add = e.target.closest ? e.target.closest("[data-add]") : null;
    if (add) {
      var id = add.getAttribute("data-add");
      var it = M.itemById[id];
      setCart(C.add(cart, id, 1));
      bumpCount();
      var original = add.textContent;
      add.textContent = "Added";
      add.classList.add("is-added");
      setTimeout(function () { add.textContent = original; add.classList.remove("is-added"); }, 1100);
      toast((it ? it.name : "Item") + " added to your order");
      return;
    }
    var act = e.target.closest ? e.target.closest("[data-act]") : null;
    if (act) {
      var aid = act.getAttribute("data-id"), kind = act.getAttribute("data-act");
      var q = cart[aid] || 0;
      if (kind === "inc") setCart(C.setQty(cart, aid, q + 1));
      else if (kind === "dec") setCart(C.setQty(cart, aid, q - 1));
      else if (kind === "remove") setCart(C.remove(cart, aid));
      // keep focus on the same control after re-render
      var sel = '[data-act="' + kind + '"][data-id="' + aid + '"]';
      var again = drawer.querySelector(sel);
      if (again) again.focus(); else if ($("cart-checkout") && !$("cart-checkout").disabled) $("cart-checkout").focus(); else { var first = drawer.querySelector(".drawer__head .icon-btn"); if (first) first.focus(); }
    }
  });
  $("cart-checkout").addEventListener("click", openCheckout);

  /* ---------- Checkout ---------- */
  var built = false;
  var orderTypeSel = "in-house";
  var paySel = null;

  function buildOptions() {
    if (built) return;
    built = true;
    var types = $("co-types");
    C.ORDER_TYPES.forEach(function (ot) {
      var id = "ot-" + ot.id;
      var input = el("input", { type: "radio", name: "orderType", value: ot.id, id: id });
      if (ot.id === orderTypeSel) input.checked = true;
      var inner = el("span", { class: "co-type__body" }, [el("strong", { text: ot.name }), el("small", { text: ot.hint })]);
      types.appendChild(el("label", { class: "co-type", for: id }, [input, inner]));
    });
    var wrap = $("co-pay");
    C.PAYMENT_METHODS.forEach(function (m, i) {
      var id = "pm-" + m.id;
      var input = el("input", { type: "radio", name: "payment", value: m.id, id: id });
      var monoEl = el("span", { class: "pay__mono", "aria-hidden": "true", text: m.mono });
      var text = el("span", { class: "pay__tile-text" }, [el("strong", { text: m.name }), el("small", { text: m.kind })]);
      var dot = el("span", { class: "pay__tile-dot", "aria-hidden": "true" });
      var inner = el("span", { class: "pay__tile-inner tilt-inner" }, [monoEl, text, dot]);
      var label = el("label", { class: "pay__tile reveal is-visible", for: id }, [input, inner]);
      label.style.setProperty("--d", (i * 60) + "ms");
      wrap.appendChild(label);
    });
    types.addEventListener("change", function (e) {
      if (e.target.name !== "orderType") return;
      orderTypeSel = e.target.value;
      $("co-address-wrap").hidden = orderTypeSel !== "delivery";
      clearError("orderType");
    });
    wrap.addEventListener("change", function (e) {
      if (e.target.name !== "payment") return;
      paySel = e.target.value;
      var m = C.PAYMENT_METHODS.filter(function (x) { return x.id === paySel; })[0];
      $("co-pay-note").textContent = m ? m.note : "";
      clearError("payment");
    });
  }

  function prepareCheckout() {
    buildOptions();
    $("checkout-form").hidden = false;
    $("co-done").hidden = true;
    renderSummary();
    clearAllErrors();
  }

  function renderSummary() {
    var ls = C.lines(cart, M.items);
    var t = C.totals(ls);
    var list = $("co-lines");
    list.innerHTML = "";
    ls.forEach(function (l) {
      list.appendChild(el("li", {}, [
        el("span", { text: l.qty + " \u00D7 " + l.item.name }),
        el("span", { text: C.formatTk(l.lineTotal) + (l.isFrom ? "+" : "") })
      ]));
    });
    $("co-total").textContent = C.formatTk(t.subtotal) + (t.hasFromPrice ? "+" : "");
    $("co-from").hidden = !t.hasFromPrice;
  }

  function clearError(key) {
    var e = $("err-" + key);
    if (e) { e.hidden = true; e.textContent = ""; }
  }
  function clearAllErrors() { ["name", "phone", "orderType", "address", "payment"].forEach(clearError); }
  function showError(key, msg) {
    var e = $("err-" + key);
    if (e) { e.textContent = msg; e.hidden = false; }
  }

  function readForm() {
    var f = $("checkout-form");
    var pay = f.querySelector('input[name="payment"]:checked');
    var type = f.querySelector('input[name="orderType"]:checked');
    return {
      name: $("co-name").value,
      phone: $("co-phone").value,
      orderType: type ? type.value : null,
      address: $("co-address").value,
      payment: pay ? pay.value : null
    };
  }

  $("checkout-form").addEventListener("submit", function (e) {
    e.preventDefault();
    clearAllErrors();
    var form = readForm();
    var result = C.validate(form);
    if (!result.ok) {
      Object.keys(result.errors).forEach(function (k) { showError(k, result.errors[k]); });
      var firstKey = Object.keys(result.errors)[0];
      var target = { name: "co-name", phone: "co-phone", orderType: "ot-" + (form.orderType || "in-house"), address: "co-address", payment: "pm-" + (form.payment || "bkash") }[firstKey];
      var node = $(target) || document.querySelector('[name="' + firstKey + '"]');
      if (node) node.focus();
      return;
    }
    submitDemoOrder(form);
  });

  function submitDemoOrder(form) {
    var ls = C.lines(cart, M.items);
    var t = C.totals(ls);
    var ref = C.demoRef(Date.now());
    var method = C.PAYMENT_METHODS.filter(function (m) { return m.id === form.payment; })[0];
    var typeName = C.ORDER_TYPES.filter(function (o) { return o.id === form.orderType; })[0].name;
    if (DEMO_MODE) {
      // Demo only: nothing is sent and nothing is charged.
    }
    $("checkout-form").hidden = true;
    $("done-ref").textContent = ref;
    $("done-summary").textContent = t.count + (t.count === 1 ? " item" : " items") + " \u00B7 " + typeName + " \u00B7 " + method.name + " (not charged) \u00B7 Total " + C.formatTk(t.subtotal) + (t.hasFromPrice ? "+" : "");
    $("co-done").hidden = false;
    setCart({});
    setTimeout(function () { $("co-done").focus(); }, 60);
  }

  render();
})();
