/*
 * Vive Study Cafe — shared menu dataset (single source of truth)
 * --------------------------------------------------------------
 * Used by the main website (index.html) AND the Smart Food Matcher
 * (food-matcher/index.html). Loaded as a classic script so the site
 * also works when opened straight from disk.
 *
 * Data rules (from the project brief):
 *  - Names, descriptions and prices are copied exactly as supplied.
 *    Spelling is NOT corrected (e.g. "Chicken Mashroom", "Oreo MIlkShake").
 *  - `description` is null where the brief supplied none. Nothing is invented.
 *  - `priceLabel` is the exact text shown to users ("Tk 380", "From Tk 290").
 *    `price` is the numeric value used only for sorting/reference.
 *  - `tastes` is an explicit matching tag list for the Smart Food Matcher.
 *    A tag is only added when the name or the supplied description states it
 *    (e.g. "Mango" in "Mango with lime and spicy"). It is NOT an ingredient,
 *    allergen or dietary claim. "savory" marks a savory food item in general.
 *    Items with no clear basis get an empty list and are only reachable by name.
 *  - Mocha Madness' description was supplied in quotation marks; the marks
 *    are presentation only and are not stored.
 */
(function (root) {
  "use strict";

  var CURRENCY = { code: "BDT", symbol: "Tk", name: "Bangladeshi Taka" };

  var categories = [
    { id: "espresso",   name: "ESPRESSO DRINKS",     image: "images/cat-espresso.jpg",  imageAlt: "Illustrative image: espresso and cappuccino cups on dark slate" },
    { id: "refreshers", name: "REFRESHERS",          image: "images/cat-refresher.jpg", imageAlt: "Illustrative image: iced refresher drinks with lime and berries" },
    { id: "sandwiches", name: "SANDWICHES",          image: "images/cat-sandwich.jpg",  imageAlt: "Illustrative image: layered club sandwich on a wooden board" },
    { id: "combo",      name: "COMBO",               image: null,                       imageAlt: "" },
    { id: "breakfast",  name: "ALL DAY BREAKFAST!",  image: "images/cat-breakfast.jpg", imageAlt: "Illustrative image: English breakfast plate with eggs, sausages and toast" },
    { id: "dumplings",  name: "DUMPLINGS",           image: "images/cat-dumpling.jpg",  imageAlt: "Illustrative image: steamed dumplings with chili oil" },
    { id: "milkshakes", name: "MILKSHAKES",          image: "images/cat-milkshake.jpg", imageAlt: "Illustrative image: three milkshakes with straws" },
    { id: "tea",        name: "TEA",                 image: "images/cat-tea.jpg",       imageAlt: "Illustrative image: teapot and cups of tea with lemon and honey" },
    { id: "water",      name: "WATER",               image: "images/cat-water.jpg",     imageAlt: "Illustrative image: chilled glass of water with lime" },
    { id: "brain-foods",name: "BRAIN FOODS",         image: "images/cat-parfait.jpg",   imageAlt: "Illustrative image: layered yogurt parfaits with granola and berries" },
    { id: "add-on",     name: "ADD ON",              image: "images/cat-addon.jpg",     imageAlt: "Illustrative image: caramel and chocolate sauces with hazelnuts" },
    { id: "pasta-salad",name: "HEALTHY PASTA SALAD", image: "images/cat-pasta.jpg",     imageAlt: "Illustrative image: pasta salad in a ceramic bowl" },
    { id: "specials",   name: "VIVE'S SPECIALS",     image: "images/cat-specials.jpg",  imageAlt: "Illustrative image: iced espresso drink and affogato" }
  ];

  // Helper to keep the table compact. Fields: id, name, category, price, priceLabel, description, tastes
  function item(id, name, category, price, description, tastes, fromPrefix) {
    return {
      id: id,
      name: name,
      category: category,
      price: price,
      priceLabel: (fromPrefix ? "From " : "") + "Tk " + price,
      description: description || null,
      tastes: tastes || []
    };
  }

  var items = [
    // 1. ESPRESSO DRINKS (9)
    item("flavored-latte", "Flavored Latte", "espresso", 380, null, ["coffee", "creamy"]),
    item("choco-espresso", "Choco Espresso", "espresso", 295, null, ["coffee", "chocolate"]),
    item("cappuccino", "Cappuccino", "espresso", 290, "A Perfect Blend of Espresso and Velvety Foam", ["coffee", "creamy"]),
    item("mocha-madness", "Mocha Madness", "espresso", 465, "A Decadent Coffee Delight with a Twist!", ["coffee", "chocolate"]),
    item("latte", "Latte", "espresso", 280, "Smooth, Creamy, and Comforting!", ["coffee", "creamy"]),
    item("espresso", "Espresso", "espresso", 180, "Pure, Bold Coffee Essence.", ["coffee"]),
    item("americano", "Americano", "espresso", 230, "Rich Espresso Meets Hot Water Harmony.", ["coffee"]),
    item("cafe-mocha", "Cafe Mocha", "espresso", 420, "Chocolate Bliss Meets Rich Espresso.", ["coffee", "chocolate"]),
    item("espresso-macchiato", "Espresso Macchiato", "espresso", 265, null, ["coffee"]),

    // 2. REFRESHERS (6)
    item("tropical-fizz", "Tropical Fizz", "refreshers", 300, null, ["refreshing"]),
    item("orange-mojito", "Orange Mojito", "refreshers", 300, null, ["refreshing", "fruity"]),
    item("spiced-summer", "Spiced Summer", "refreshers", 300, "Mango with lime and spicy.", ["refreshing", "fruity"]),
    item("blue-ocean-lime", "Blue Ocean Lime", "refreshers", 300, "A splash of ocean breeze, a twist of lime – the perfect summer refresher!", ["refreshing", "fruity"]),
    item("strawberry-lime", "Strawberry Lime", "refreshers", 300, null, ["refreshing", "fruity"]),
    item("espresso-soda-refresher", "Espresso Soda Refresher", "refreshers", 280, null, ["refreshing", "coffee"]),

    // 3. SANDWICHES (4)
    item("smoked-chicken-sandwich", "Smoked Chicken Sandwich", "sandwiches", 290, null, ["savory"]),
    item("roasted-beef-sandwich", "Roasted Beef Sandwich", "sandwiches", 430, null, ["savory"]),
    item("three-layered-club-sandwich", "Three Layered Club Sandwich", "sandwiches", 350, "Classic Combination of Egg and Cheese with Smoked Chicken. Three Layered of Bread.", ["savory"]),
    item("tuna-sandwich", "Tuna Sandwich", "sandwiches", 400, null, ["savory"]),

    // 4. COMBO (2)
    item("favourites", "Favourites", "combo", 445, null, []),
    item("luxury-saver", "Luxury saver", "combo", 445, null, []),

    // 5. ALL DAY BREAKFAST! (2)
    item("regular-english-breakfast", "Regular English Breakfast", "breakfast", 320, "Includes - Slices of Toasted Bread, Chicken Sausages, 1 x Sunny Side Up Egg, Fruit Jam, Grilled Tomato", ["savory"]),
    item("complete-english-breakfast", "Complete English Breakfast", "breakfast", 430, "Includes - Slices of Toasted Bread, Chicken Sausages, 2 x Sunny Side Up Egg, Fruit Jam, Grilled Tomato, Baked Beans, A Black Tea", ["savory"]),

    // 6. DUMPLINGS (2)
    item("chicken-mushroom-dumpling", "Chicken Mushroom Dumpling", "dumplings", 290, null, ["savory"], true),
    item("chicken-mashroom-with-chili-oil", "Chicken Mashroom with Chili Oil", "dumplings", 345, null, ["savory"]),

    // 7. MILKSHAKES (3)
    item("chocolate-milkshake", "Chocolate Milkshake", "milkshakes", 350, null, ["chocolate", "creamy", "sweet"]),
    item("oreo-milkshake", "Oreo MIlkShake", "milkshakes", 350, null, ["creamy", "sweet"]),
    item("strawberry-milkshake", "Strawberry Milkshake", "milkshakes", 350, null, ["fruity", "creamy", "sweet"]),

    // 8. TEA (4)
    item("ginger-tea", "Ginger Tea", "tea", 180, null, ["tea"]),
    item("iced-tea", "Iced Tea", "tea", 230, null, ["tea"]),
    item("organic-tea", "Organic Tea", "tea", 180, null, ["tea"]),
    item("honey-lemon-tea", "Honey Lemon Tea", "tea", 180, null, ["tea"]),

    // 9. WATER (1)
    item("mineral-water", "Mineral Water", "water", 20, null, []),

    // 10. BRAIN FOODS (4)
    item("chocolate-yogurt-parfait", "Chocolate Yogurt Parfait", "brain-foods", 295, "Yogurt and Vanilla Layered with Chocolate Flavor.", ["chocolate", "creamy", "sweet"]),
    item("strawberry-yogurt-parfait", "Strawberry Yogurt Parfait", "brain-foods", 295, "Yogurt and Parfait with Strawberry Flavor", ["fruity", "creamy", "sweet"]),
    item("mango-yogurt-parfait", "Mango Yogurt Parfait", "brain-foods", 295, "Yogurt and Granula with Mango Flavor.", ["fruity", "creamy", "sweet"]),
    item("caramel-yogurt-parfait", "caramel yogurt parfait", "brain-foods", 295, null, ["creamy", "sweet"]),

    // 11. ADD ON (3)
    item("hazelnut", "hazelnut", "add-on", 85, null, []),
    item("caramel-sauce", "caramel sauce", "add-on", 105, null, []),
    item("chocolate-sauce", "chocolate sauce", "add-on", 105, null, []),

    // 12. HEALTHY PASTA SALAD (2)
    item("tuna-pasta-salad", "Tuna Pasta Salad", "pasta-salad", 390, null, ["savory"]),
    item("italian-pasta-salad", "Italian Pasta Salad", "pasta-salad", 350, null, ["savory"]),

    // 13. VIVE'S SPECIALS (7)
    item("iced-mango-americano", "Iced Mango Americano", "specials", 335, null, ["coffee", "fruity"]),
    item("iced-orange-americano", "Iced Orange Americano", "specials", 350, null, ["coffee", "fruity"]),
    item("espresso-on-the-rocks", "Espresso on the rocks", "specials", 285, null, ["coffee"]),
    item("berry-espresso", "Berry Espresso", "specials", 265, null, ["coffee", "fruity"]),
    item("affogato", "Affogato", "specials", 290, null, ["coffee"]),
    item("crunch-affogato", "Crunch Affogato", "specials", 330, null, ["coffee"]),
    item("vives-spanish-latte", "Vive's Spanish Latte", "specials", 350, "Rich and Sweet, with a Spanish Flair.", ["coffee", "sweet", "creamy"])
  ];

  var categoryById = {};
  categories.forEach(function (c) { categoryById[c.id] = c; });

  var itemById = {};
  items.forEach(function (it) { itemById[it.id] = it; });

  function itemsIn(categoryId) {
    return items.filter(function (it) { return it.category === categoryId; });
  }

  root.ViveMenu = {
    brand: "Vive Study Cafe",
    currency: CURRENCY,
    categories: categories,
    items: items,
    categoryById: categoryById,
    itemById: itemById,
    itemsIn: itemsIn
  };
})(typeof window !== "undefined" ? window : globalThis);
