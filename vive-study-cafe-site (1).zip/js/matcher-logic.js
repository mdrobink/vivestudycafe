/*
 * Smart Food Matcher — matching logic (pure functions, no DOM).
 * Works in the browser (window.ViveMatcher) and in Node for tests.
 *
 * Rules:
 *  1. Meal type decides the candidate pool (e.g. "Sandwich" -> SANDWICHES).
 *  2. Taste narrows the pool to items whose explicit tags match the taste.
 *  3. If taste and meal conflict (no item in the meal matches the taste),
 *     the MEAL wins: the user gets an item from the chosen meal plus an honest
 *     explanation. Nothing is fabricated.
 *  4. "Other menu item" is a name search. If nothing matches, the result is
 *     an explicit no-match state with no recommendation.
 */
(function (root) {
  "use strict";

  var TASTES = [
    { id: "coffee",   label: "Coffee-forward",         hint: "Bold espresso and coffee drinks",  match: ["coffee"] },
    { id: "chocolate",label: "Chocolate",              hint: "Chocolate-flavoured choices",       match: ["chocolate"] },
    { id: "fruity",   label: "Fruity and refreshing",  hint: "Drinks and treats with a named fruit", match: ["fruity"] },
    { id: "creamy",   label: "Creamy and sweet",       hint: "Smooth, creamy or sweet choices",   match: ["creamy", "sweet"] },
    { id: "tea",      label: "Tea",                    hint: "From our tea selection",            match: ["tea"] },
    { id: "savory",   label: "Savory food",            hint: "Sandwiches, breakfast, dumplings and more", match: ["savory"] },
    { id: "other",    label: "Other / not sure",       hint: "Show me what's on offer",           match: null }
  ];

  var MEALS = [
    { id: "espresso",  label: "Espresso / Coffee", categories: ["espresso", "specials"] },
    { id: "refresher", label: "Refresher",         categories: ["refreshers"] },
    { id: "sandwich",  label: "Sandwich",          categories: ["sandwiches"] },
    { id: "breakfast", label: "Breakfast",         categories: ["breakfast"] },
    { id: "dumplings", label: "Dumplings",         categories: ["dumplings"] },
    { id: "milkshake", label: "Milkshake",         categories: ["milkshakes"] },
    { id: "tea",       label: "Tea",               categories: ["tea"] },
    { id: "parfait",   label: "Yogurt Parfait",    categories: ["brain-foods"] },
    { id: "pasta",     label: "Pasta Salad",       categories: ["pasta-salad"] },
    { id: "other",     label: "Other menu item",   categories: null }
  ];

  function findTaste(id) { return TASTES.filter(function (t) { return t.id === id; })[0] || null; }
  function findMeal(id) { return MEALS.filter(function (m) { return m.id === id; })[0] || null; }

  function normalise(s) { return String(s || "").toLowerCase().replace(/\s+/g, " ").trim(); }

  function itemMatchesTaste(item, taste) {
    if (!taste || !taste.match) return true;
    return item.tastes.some(function (tag) { return taste.match.indexOf(tag) !== -1; });
  }

  /**
   * @param {Array} allItems   shared menu items (ViveMenu.items)
   * @param {Object} opts      { taste: id, meal: id, query: string }
   * @returns {Object} { status, pool, note, tasteLabel, mealLabel }
   *   status: "need-query" | "no-match" | "match" | "conflict"
   */
  function recommend(allItems, opts) {
    var taste = findTaste(opts.taste);
    var meal = findMeal(opts.meal);
    if (!taste || !meal) {
      return { status: "no-match", pool: [], note: "Please choose a taste and a meal type.", tasteLabel: "", mealLabel: "" };
    }
    var base = { tasteLabel: taste.label, mealLabel: meal.label };

    // Path A: "Other menu item" -> search by name
    if (meal.categories === null) {
      var q = normalise(opts.query);
      if (!q) {
        return Object.assign({ status: "need-query", pool: [], note: "Type the name of a dish to search." }, base);
      }
      var found = allItems.filter(function (it) {
        return normalise(it.name).indexOf(q) !== -1;
      });
      if (!found.length) {
        return Object.assign({
          status: "no-match", pool: [],
          note: "No dish on the Vive menu matches \u201C" + String(opts.query).trim() + "\u201D. We haven\u2019t made a recommendation."
        }, base);
      }
      return Object.assign({
        status: "match", pool: found,
        note: "Search results for \u201C" + String(opts.query).trim() + "\u201D. Taste is not used for name searches."
      }, base);
    }

    // Path B: meal-based candidates
    var candidates = allItems.filter(function (it) {
      return meal.categories.indexOf(it.category) !== -1;
    });
    if (!candidates.length) {
      return Object.assign({ status: "no-match", pool: [], note: "There are no items in " + meal.label + " right now." }, base);
    }

    if (taste.id === "other") {
      return Object.assign({ status: "match", pool: candidates, note: "" }, base);
    }

    var exact = candidates.filter(function (it) { return itemMatchesTaste(it, taste); });
    if (exact.length) {
      return Object.assign({
        status: "match", pool: exact,
        note: "Matches \u201C" + taste.label + "\u201D based on its name or supplied description."
      }, base);
    }

    return Object.assign({
      status: "conflict", pool: candidates,
      note: "No " + meal.label + " item on our menu is described as \u201C" + taste.label + "\u201D, so we\u2019ve picked from " +
            meal.label + " instead. Your meal choice comes first."
    }, base);
  }

  var api = {
    TASTES: TASTES,
    MEALS: MEALS,
    findTaste: findTaste,
    findMeal: findMeal,
    recommend: recommend,
    itemMatchesTaste: itemMatchesTaste
  };

  if (typeof module !== "undefined" && module.exports) { module.exports = api; }
  root.ViveMatcher = api;
})(typeof window !== "undefined" ? window : globalThis);
